<?php
$testingDirectory = __DIR__;
require "/user/cse477/classweb/student/test/testrunner.php";
